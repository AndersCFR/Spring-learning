package com.anderscfr.simple_rest_example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleRestExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
